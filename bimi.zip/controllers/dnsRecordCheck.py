from flask_restful import Resource,request
import json
import subprocess
import dkim
from certvalidator import CertificateValidator, errors
class getDnsRecords(Resource):
    def post(self):
        content = request.json
        content['domain']
        # CERTIFICATE VALIDATOR
        '''with open('storage/certificates/pepitest.crt', 'rb') as f:
            end_entity_cert = f.read()
        try:
            validator = CertificateValidator(end_entity_cert)
        except (errors.PathValidationError):
            print("Cannot verify certificate. Issue: %s",errors.PathValidationError)'''

        
        # DKIM CHECK
        '''dkimRecord = {"status": "", "record": "","message":""}
        try:
            result = subprocess.run(['dig','8.8.8.8._domainkey.pepipost.com','TXT'], stdout=subprocess.PIPE)
        except:
            print("error in executing command line")
        # res = dkim.verify(result, tlsrpt='strict')
        return result'''

        # Check sfp dmarc mx
        result = subprocess.run(['checkdmarc', content['domain']], stdout=subprocess.PIPE)
        complied_dict = json.loads(result.stdout)
        # return complied_dict

        # MX CHECK
        mxRecord = {"status": "", "records": [],"message":""}
        if  len(complied_dict['mx']['hosts']) == 0:
            mxRecord['status'] = False
            mxRecord['message'] = complied_dict['mx']['warnings']
        else:
            for host in complied_dict['mx']['hosts']: 
                mxRecord['records'].append(host['hostname'])
                mxRecord['status'] = True
                mxRecord['message'] = complied_dict['mx']['warnings']

        # SPF CHECK
        spfRecord = {"status": "", "record": "","message":""}
        if  complied_dict['spf']['record'] in (None, ''):
            spfRecord['status'] = False
            spfRecord['message'] = complied_dict['spf']['error']
        else:
            spfRecord['status'] = complied_dict['spf']['valid']
            spfRecord['message'] = complied_dict['spf']['warnings']
            spfRecord['record'] = complied_dict['spf']['record']

        # DMARC CHECK
        dmarcRecord = {"status": "", "record": "","message":""}
        if complied_dict['dmarc']['record'] in (None, ''):
            dmarcRecord['status'] = False
            dmarcRecord['message'] = complied_dict['dmarc']['error']
        else:
            dmarcRecord['status'] = complied_dict['dmarc']['valid']
            dmarcRecord['message'] = complied_dict['dmarc']['warnings']
            dmarcRecord['record'] = complied_dict['dmarc']['record']  

        response = {"mx":mxRecord, "spf":spfRecord, "dmarc":dmarcRecord}
        return response
