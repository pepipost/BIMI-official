from flask import Flask,redirect,url_for,request, render_template

app = Flask(__name__, template_folder='templates')

@app.route('/')
def hello():
    return 'Hello, World!'

@app.route('/<name>')
def chello(name):
    return 'Hello, %s!' %name

@app.route('/number/<int:number>')
def nello(number):
    return 'Hello, %d!' %number

@app.route('/float/<float:floatval>')
def fello(floatval):
    return 'Hello, %f!' %floatval

@app.route('/admin')
def adello():
    return 'Hello, Admin!'

@app.route('/guest/<guest>')
def guello(guest):
    return 'Hello, Guest! %s' %guest

@app.route('/user/<name>')
def hello_user(name):
    if name == 'admin':
        return redirect(url_for('adello'))
    else:
        return redirect(url_for('guello', guest=name))

@app.route('/success/<name>')
def success(name):
    return 'Welcome! %s' %name

@app.route('/result')
def result():
    dicts = {'phy': 66, 'chem': 44, 'maths': 35}
    return render_template('marks.html', result=dicts)

@app.route('/login',methods = ['POST','GET'])
def login():
    if request.method == 'POST':
        user = request.form['user']
        # return redirect(url_for('success', name=user))
        return render_template('hello.html', name=user)
    else:
        user = request.args.get('user')
        # return redirect(url_for('success', name=user))
        return render_template('hello.html', name=user)

if __name__ == '__main__':
    app.debug = True
    app.run()