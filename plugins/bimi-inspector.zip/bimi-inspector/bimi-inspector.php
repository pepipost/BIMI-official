<?php
/**
* @package BIMIInspector
*/
/* Plugin Name: BIMI Inspector
* Plugin URI: https://github.com/pepipost/BIMI-official
* Description: Check and Validate your bimi record in a single click. You can also generate a new BIMI record if you don't have one.
* Author: Hitesh Pandey
* Author URI: https://github.com/Hiteshpandey/
* Version: 1.0.0
* License: MIT
* Text Domain: bimi-inspector
*/

/*
License Text
*/

if (! function_exists( 'add_action' ) ){
	die( 'WP Instance is not defined' );
}

// Load necessary scripts
function func_load_vuescripts() {
	wp_register_script('wpbimi_vuejs', 'https://cdn.jsdelivr.net/npm/vue@2.6.12/dist/vue.min.js');
	wp_register_script('wpbimi_axios', 'https://cdnjs.cloudflare.com/ajax/libs/axios/0.20.0/axios.min.js');
	wp_register_script('wpbimi_bootstrap_vue', '//unpkg.com/bootstrap-vue@2.16.0/dist/bootstrap-vue.min.js');
	wp_register_script('wpbimi_babel_polyfill', 'https://cdnjs.cloudflare.com/ajax/libs/babel-polyfill/7.11.5/polyfill.js');
	wp_register_script('wpbimi_mainjs', plugin_dir_url( __FILE__ ).'assets/js/main.js', 'wpbimi_vuejs', true );
}
add_action('wp_enqueue_scripts', 'func_load_vuescripts');

function func_load_vuestyles() {
	wp_register_style('wpbimi_bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css', array(), '4.5.2', false);
	wp_register_style('wpbimi_fonts',  plugin_dir_url( __FILE__ ).'assets/fonts/fontstyle.css', array(), '1.1.1', false);
	wp_register_style('wpbimi_mainstyle',  plugin_dir_url( __FILE__ ).'assets/css/main.css', array(), '1.1.1', false);
}
add_action('wp_head', 'func_load_vuestyles');

// Set html content
function func_wp_bimi(){
	// Add js
	wp_enqueue_script('wpbimi_vuejs');
	wp_enqueue_script('wpbimi_axios');
	wp_enqueue_script('wpbimi_bootstrap_vue');
	wp_enqueue_script('wpbimi_babel_polyfill');
	wp_enqueue_script('wpbimi_mainjs');

	// Add CSS
	wp_enqueue_style('wpbimi_bootstrap');
	wp_enqueue_style('wpbimi_fonts');
	wp_enqueue_style('wpbimi_mainstyle');

	$string_content = file_get_contents(plugin_dir_url( __FILE__ ).'assets/pages/main.html');
	$pathscript = "<script type = 'text/javascript'>
		var pluginURL =  '" . plugin_dir_url( __FILE__ ) . "';
	</script>";
	return $string_content .= $pathscript;

}

// Enable shotcode for bimi app
add_shortcode( 'wpbimiinspector', 'func_wp_bimi' );